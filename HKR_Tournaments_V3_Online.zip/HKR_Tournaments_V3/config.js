// Copy this file to config.local.js and put your Supabase project values here.
// NEVER put a Supabase secret/service_role key in this file or in the APK.
window.HKR_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_PUBLISHABLE_KEY: "YOUR_SUPABASE_PUBLISHABLE_KEY"
};
